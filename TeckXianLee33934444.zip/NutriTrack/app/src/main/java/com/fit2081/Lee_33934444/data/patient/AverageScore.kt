package com.fit2081.Lee_33934444.data.patient

data class AverageScore (
    val sex: String,
    val AverageScore: Double,
)