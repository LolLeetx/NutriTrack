package com.fit2081.Lee_33934444.dataclass

data class DataPattern(
    val pattern1Key: String? = null,
    val pattern1info: String? = null,
    val pattern2Key: String? = null,
    val pattern2info: String? = null,
    val pattern3Key: String? = null,
    val pattern3info: String? = null,
)
